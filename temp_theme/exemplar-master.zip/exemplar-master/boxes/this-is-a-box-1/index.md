---
layout: default
title: This is a box
box: true
summary: Boxes make up a small 2 column grid on larger screens and shrink to single column on smaller screens
---
