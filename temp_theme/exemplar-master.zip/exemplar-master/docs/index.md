---
title: Docs
nav: projects
subnav: exemplar-docs
layout: default
---

Exemplar doesn't have much in the way of documentation. Use git to download, tweak in your favorite editor and "rake -T" to get a list of jekyll/sass/git tasks.

This is here as more of an example.

{% highlight ruby %}
class Foo < Bar
  def foobar
    return "This shows what code snippets look like in Exemplar"
  end
end
{% endhighlight %}
